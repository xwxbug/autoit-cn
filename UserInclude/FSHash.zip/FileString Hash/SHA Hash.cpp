/*
 * Plugin for AutoItv3
 * SHAHash()
 * SHA-1 Hashes supported.
 * SHA functions by Jarvis Stubblefield (jjs at vortexrevolutions dot com)
 * Special thanks to all the supporters.
 * Plugin_SDK and AutoItv3 Jon Bennett and his team of Developers
 *
 * SHA Hash.cpp
 */

#include <stdio.h>
#include <windows.h>
#include "SRC_SDK\au3plugin.h"
#include "SRC_SHA\JSsha.h"


/****************************************************************************
 * Function List
 *
 * This is where you define the functions available to AutoIt.  Including
 * the function name (Must be the same case as your exported DLL name), the
 * minimum and maximum number of parameters that the function takes.
 *
 ****************************************************************************/

/* "FunctionName", min_params, max_params */
AU3_PLUGIN_FUNC g_AU3_Funcs[1] =
{
    {"SHAHash", 2, 3}
};

/****************************************************************************
 * AU3_GetPluginDetails()
 *
 * This function is called by AutoIt when the plugin dll is first loaded to
 * query the plugin about what functions it supports.  DO NOT MODIFY.
 *
 ****************************************************************************/

AU3_PLUGINAPI int AU3_GetPluginDetails(int *n_AU3_NumFuncs, AU3_PLUGIN_FUNC **p_AU3_Func)
{
	/* Pass back the number of functions that this DLL supports */
	*n_AU3_NumFuncs	= sizeof(g_AU3_Funcs)/sizeof(AU3_PLUGIN_FUNC);;

	/* Pack back the address of the global function table */
	*p_AU3_Func = g_AU3_Funcs;

	return AU3_PLUGIN_OK;
}

/****************************************************************************
 * DllMain()
 *
 * This function is called when the DLL is loaded and unloaded.  Do not
 * modify it unless you understand what it does...
 *
 ****************************************************************************/

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

/****************************************************************************
 * SHAHash()
 *
 * This function should return a hash of the chosen file or string.
 * Accepts 3 parameters:
 *
 * SHAHash(string StringFile, int HashType[, bool ReturnCase])
 * SHAHash("filename.exe", 1[, 0])
 * SHAHash("This is a string", 2[, 0])
 *
 * 1st Parameter = The file or string you wish to return a hash value of.
 * 2nd Parameter = Type of hash to be performed. (File or String)
 * 3rd Parameter = Uppercase or Lowercase return string. **Optional**
 *
 ****************************************************************************/
AU3_PLUGIN_DEFINE(SHAHash) {
    AU3_PLUGIN_VAR  *p_HResult;
    char            *s_String, *s_Hash;
    int             i_Hash;
    bool            b_Case;

    p_HResult = AU3_AllocVar();

    /* Check to be sure the variables are of the right types. */
	//Set @error to 1 if first variable is not a string.
	if (AU3_GetType(&p_AU3_Params[0]) != AU3_PLUGIN_STRING) {
	    AU3_SetInt32(p_HResult, 0);
		*p_AU3_Result		= p_HResult;
		*n_AU3_ErrorCode	= 1;
		*n_AU3_ExtCode		= 0;

		return AU3_PLUGIN_OK;
	}
	else {
	    //Note: Free s_String when finished.
	    s_String = AU3_GetString(&p_AU3_Params[0]);
	}

	//Set @error to 2 if second variable is not an integer
	if (AU3_GetType(&p_AU3_Params[1]) != AU3_PLUGIN_INT32) {
	    AU3_SetInt32(p_HResult, 0);
		*p_AU3_Result		= p_HResult;
		*n_AU3_ErrorCode	= 2;
		*n_AU3_ExtCode		= 0;

		return AU3_PLUGIN_OK;
	}
	else {
	    i_Hash = AU3_GetInt32(&p_AU3_Params[1]);
	}
	//Set @error to 2 if second variable isnt 1 or 2 and set @extended to 1
	if (i_Hash == 1) {
	    s_Hash = FileSHAEncrypt(s_String);
	}
	else if (i_Hash == 2) {
	    s_Hash = StringSHAEncrypt(s_String);
	}
    else {
        AU3_SetInt32(p_HResult, 0);
		*p_AU3_Result		= p_HResult;
		*n_AU3_ErrorCode	= 2;
		*n_AU3_ExtCode		= 1;

		return AU3_PLUGIN_OK;
    }
	//Set @error to 3 if third variable exists, and isnt an integer
	if (n_AU3_NumParams == 3) {
	    if (AU3_GetType(&p_AU3_Params[2]) != AU3_PLUGIN_INT32) {
            AU3_SetInt32(p_HResult, 0);
            *p_AU3_Result		= p_HResult;
            *n_AU3_ErrorCode	= 3;
            *n_AU3_ExtCode		= 0;

            return AU3_PLUGIN_OK;
	    }
	    else {
	        b_Case = (bool)AU3_GetInt32(&p_AU3_Params[2]);
	    }
	}
	else {
	    b_Case = false;
	}
	//Set @error to 4 if s_Hash = false
	if (s_Hash == false) {
        AU3_SetInt32(p_HResult, 0);
        *p_AU3_Result		= p_HResult;
        *n_AU3_ErrorCode	= 1;
        *n_AU3_ExtCode		= 1;

        return AU3_PLUGIN_OK;
	}
    //Set hash to Upper or Lower case.
    if (b_Case) {
        strupr(s_Hash);
    }
    else {
        strlwr(s_Hash);
    }

    AU3_SetString(p_HResult, s_Hash);

    //From note above. Freeing s_String
	AU3_FreeString(s_String);

	/* Pass back the result, error code and extended code. */
	*p_AU3_Result		= p_HResult;
	*n_AU3_ErrorCode    = 0;
	*n_AU3_ExtCode		= 0;

	return AU3_PLUGIN_OK;
}
